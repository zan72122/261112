"""索引: 段落 (passage) 単位の BM25、キー: 値 の事実、型番エンティティ。"""
from __future__ import annotations

import math
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from pathlib import Path

from .pdftext import extract_passages

HIRA = "ぁ-ゖ"
KATA = "ァ-ヺー"
KANJI = "㐀-鿿々〆"
CJK = HIRA + KATA + KANJI

_CJK_RUN = re.compile(f"[{CJK}]+")
_ALNUM = re.compile(r"[a-z0-9]+(?:[-.:/][a-z0-9]+)*")
_PURE_HIRA = re.compile(f"^[{HIRA}]+$")
_KANJI_CH = re.compile(f"[{KANJI}]")

# 型番: 英字 1-4 + (ハイフン) + 数字 + 英字 0-3  例: FR-228K, OT-12
MODEL_RE = re.compile(r"(?<![A-Za-z0-9])[A-Z]{1,4}-?\d{1,5}[A-Z]{0,3}(?![A-Za-z0-9])")
# 「キー: 値」形式の行
FACT_RE = re.compile(r"^([^:：。、]{1,20}?)\s*[:：]\s*(\S.*)$")
# 型番を宣言するキー (一般的な呼び名)
IDENTITY_KEYS = ("型番", "型式", "品番", "機種", "モデル", "製品番号")


def norm(s: str) -> str:
    """照合用の正規化 (全角英数 -> 半角、小文字化、空白の圧縮)。"""
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s)).lower().strip()


def tokenize(s: str) -> list[str]:
    """辞書なしの日本語トークン化: 英数字はそのまま、和文は文字 2-gram (+漢字 1-gram)。"""
    s = norm(s)
    toks: list[str] = []
    for m in _ALNUM.finditer(s):
        w = m.group(0)
        toks.append(w)
        parts = re.split(r"[-.:/]", w)
        if len(parts) > 1:
            toks.extend(p for p in parts if p)
    for m in _CJK_RUN.finditer(s):
        run = m.group(0)
        toks.extend(run[i:i + 2] for i in range(len(run) - 1))
        toks.extend(ch for ch in run if _KANJI_CH.match(ch))
    return toks


def token_weight(tok: str) -> float:
    if tok[0].isascii():
        if re.search(r"[a-z]", tok) and re.search(r"\d", tok):
            return 1.5            # 型番など
        return 1.0 if len(tok) > 1 else 0.5
    if len(tok) == 1:
        return 0.3                # 漢字 1 文字
    if _PURE_HIRA.match(tok):
        return 0.4                # ひらがなだけの 2-gram (助詞など) は軽く
    return 1.0


def split_sentences(text: str) -> list[str]:
    """「。」で文に分ける (括弧の中では切らない)。"""
    out, buf, depth = [], "", 0
    for ch in text:
        buf += ch
        if ch in "（(「『":
            depth += 1
        elif ch in "）)」』":
            depth = max(0, depth - 1)
        elif ch in "。！？!?" and depth == 0:
            out.append(buf.strip())
            buf = ""
    if buf.strip():
        out.append(buf.strip())
    return out


@dataclass
class Passage:
    pid: int
    file: str
    title: str
    text: str
    is_title: bool = False
    key: str | None = None        # 「キー: 値」のキー
    value: str | None = None
    tf: Counter = field(default_factory=Counter)
    length: float = 0.0

    @property
    def ntext(self) -> str:
        return norm(self.text)

    @property
    def sentences(self) -> list[str]:
        return split_sentences(self.text)


@dataclass
class Entity:
    model: str
    names: list[str] = field(default_factory=list)       # 製品の呼び名
    home_files: list[str] = field(default_factory=list)  # 型番を宣言している資料
    mentions: list[int] = field(default_factory=list)    # 言及している段落 id


@dataclass
class EntityHit:
    entity: Entity
    surface: str     # 質問中での呼び方
    pos: int


def _lcs(a: str, b: str) -> tuple[int, int]:
    """最長共通部分文字列 (長さ, a 内の開始位置)。"""
    best, pos = 0, -1
    prev = [0] * (len(b) + 1)
    for i in range(1, len(a) + 1):
        cur = [0] * (len(b) + 1)
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                cur[j] = prev[j - 1] + 1
                if cur[j] > best:
                    best, pos = cur[j], i - cur[j]
        prev = cur
    return best, pos


class Index:
    K1, B = 1.2, 0.5

    def __init__(self) -> None:
        self.passages: list[Passage] = []
        self.files: list[str] = []
        self.titles: dict[str, str] = {}
        self.entities: dict[str, Entity] = {}
        self.df: Counter = Counter()
        self.avg_len = 1.0
        self._title_tf: dict[str, Counter] = {}

    # ---------------------------------------------------------------- build
    def add_document(self, file: str, passages: list[str]) -> None:
        if not passages:
            return
        self.files.append(file)
        title = passages[0]
        self.titles[file] = title
        self._title_tf[file] = Counter(tokenize(title))
        for i, text in enumerate(passages):
            p = Passage(pid=len(self.passages), file=file, title=title, text=text, is_title=(i == 0))
            if i > 0:
                m = FACT_RE.match(text)
                if m and not re.fullmatch(r"\d+", m.group(1)):
                    p.key, p.value = m.group(1).strip(), m.group(2).strip()
            p.tf = Counter(tokenize(text))
            p.length = sum(token_weight(t) * c for t, c in p.tf.items())
            self.passages.append(p)

    def finalize(self) -> None:
        self.df = Counter()
        for p in self.passages:
            self.df.update(p.tf.keys())
        self.avg_len = sum(p.length for p in self.passages) / max(1, len(self.passages))
        self._build_entities()

    def _build_entities(self) -> None:
        ents: dict[str, Entity] = {}
        name_before = re.compile(f"([{KATA}{KANJI}]{{2,}})\\s*$")
        for p in self.passages:
            for m in MODEL_RE.finditer(unicodedata.normalize("NFKC", p.text)):
                e = ents.setdefault(m.group(0), Entity(model=m.group(0)))
                e.mentions.append(p.pid)
                nb = name_before.search(unicodedata.normalize("NFKC", p.text)[: m.start()])
                if nb and nb.group(1) not in e.names:
                    e.names.append(nb.group(1))
                if p.key and any(k in p.key for k in IDENTITY_KEYS) and p.value and \
                        unicodedata.normalize("NFKC", p.value).startswith(m.group(0)):
                    if p.file not in e.home_files:
                        e.home_files.append(p.file)
                    head = re.split(r"\s+", p.title)[0]
                    if head and head not in e.names:
                        e.names.append(head)
        self.entities = ents

    # --------------------------------------------------------------- lookup
    def idf(self, tok: str) -> float:
        n, df = len(self.passages), self.df.get(tok, 0)
        return math.log(1 + (n - df + 0.5) / (df + 0.5))

    def search(self, weights: dict[str, float], boost: dict[int, float] | None = None,
               limit: int | None = None) -> list[tuple[float, Passage]]:
        """重み付きトークンで BM25 検索。戻り値は (スコア, 段落) の降順リスト。"""
        out = []
        for p in self.passages:
            s = 0.0
            for tok, qw in weights.items():
                tf = p.tf.get(tok)
                if not tf:
                    continue
                denom = tf + self.K1 * (1 - self.B + self.B * p.length / self.avg_len)
                s += qw * token_weight(tok) * self.idf(tok) * tf * (self.K1 + 1) / denom
            if s <= 0:
                continue
            # 資料タイトルとの一致を少し加点 (どの資料の話かの手がかり)
            ttf = self._title_tf[p.file]
            s += 0.3 * sum(qw * token_weight(t) * self.idf(t) for t, qw in weights.items() if t in ttf)
            if boost and p.pid in boost:
                s *= boost[p.pid]
            out.append((s, p))
        out.sort(key=lambda x: (-x[0], x[1].pid))
        return out[:limit] if limit else out

    def coverage(self, weights: dict[str, float], p: Passage) -> float:
        """質問の (内容語) トークンのうち、この段落に現れる割合 (idf 重み付き)。"""
        tot = hit = 0.0
        for tok, qw in weights.items():
            if _PURE_HIRA.match(tok) or (len(tok) == 1 and not tok.isascii()):
                continue
            w = qw * token_weight(tok) * max(self.idf(tok), 0.5)
            tot += w
            if tok in p.tf:
                hit += w
        return hit / tot if tot else 0.0

    def facts(self, key: str, files: list[str] | None = None) -> list[Passage]:
        return [p for p in self.passages
                if p.key == key and (files is None or p.file in files)]

    @property
    def fact_keys(self) -> list[str]:
        return sorted({p.key for p in self.passages if p.key}, key=len, reverse=True)

    def resolve_entities(self, query: str, synonyms: dict[str, str] | None = None) -> list[EntityHit]:
        """質問に出てくる製品 (型番そのもの、または呼び名) を見つける。"""
        q = unicodedata.normalize("NFKC", query)
        for a, b in (synonyms or {}).items():
            if a in q and b not in q:
                q = q.replace(a, b)
        hits: list[EntityHit] = []
        for e in self.entities.values():
            best: tuple[int, int, str] | None = None   # (pos, -len, surface)
            m = re.search(re.escape(e.model), q, re.I)
            if m:
                before = re.search(f"([{KATA}{KANJI}]{{2,}})\\s*$", q[: m.start()])
                surface = before.group(1) if before else (e.names[0] if e.names else e.model)
                best = (m.start(), -99, surface)
            else:
                for name in e.names:
                    n, pos = _lcs(q, name)
                    # 一致部分の両端のひらがな (助詞) は呼び名に含めない
                    m2 = re.search(f"[{KATA}{KANJI}](?:[{CJK}]*[{KATA}{KANJI}])?", q[pos:pos + n])
                    if m2 and len(m2.group(0)) >= 3:
                        cand = (pos + m2.start(), -len(m2.group(0)), m2.group(0))
                        if best is None or cand[1] < best[1]:
                            best = cand
            if best:
                hits.append(EntityHit(entity=e, surface=best[2], pos=best[0]))
        hits.sort(key=lambda h: h.pos)
        return hits

    def in_scope(self, p: Passage, ents: list[Entity]) -> bool:
        """段落が指定製品についてのものか (宣言資料の中、または型番/呼び名に言及)。"""
        for e in ents:
            if p.file in e.home_files or p.pid in e.mentions:
                return True
        return False


def build_index(pdf_dir: str | Path = "pdfs", extractor: str = "auto") -> Index:
    pdf_dir = Path(pdf_dir)
    files = sorted(pdf_dir.glob("*.pdf"))
    if not files:
        raise FileNotFoundError(f"PDF が見つかりません: {pdf_dir}")
    idx = Index()
    for f in files:
        idx.add_document(f.name, extract_passages(f, extractor))
    idx.finalize()
    return idx
