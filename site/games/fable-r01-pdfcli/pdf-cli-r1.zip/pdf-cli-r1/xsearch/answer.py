"""質問 -> 答え + 根拠 (ファイル名と引用文)。

LLM は使わない。検索 (BM25) で根拠段落を選び、質問の型ごとの小さな規則で
資料の文言から答えを組み立てる (抽出型)。答えに使う語句・数値はすべて PDF 由来。

質問の型 (facet ごとに判定):
  coverage  …「〜は保証の対象か」      除外リスト / 対象外の記述 / 保証期間の計算
  when      …「いつ」                  日付と「前日」などの相対表現を解決
  which     …「どの〇〇」              「△△〇〇」という語を探し、別資料の定義と結合
  quantity  …「何 cm」「何分」         単位つき数値を抽出し、一致する資料をまとめる
  field     …「型番」「購入日」など    資料の「キー: 値」を製品ごとに引く
  default   … 上記以外                 最上位の段落をそのまま引用
"""
from __future__ import annotations

import calendar
import datetime as dt
import re
import unicodedata
from dataclasses import dataclass, field

from .index import (CJK, HIRA, IDENTITY_KEYS, KANJI, KATA, Entity, Index, Passage, norm,
                    split_sentences, tokenize)

# 呼び名のゆれ (質問側 -> 資料側)。必要なら足す。
SYNONYMS = {"洗濯機": "洗濯乾燥機"}

QWORD = re.compile(r"いつ|どの|どれ|どこ|何|なに|だれ|誰|いくら|なぜ|どう")
STOP_PHRASES = ("教えてください", "教えて", "ください", "ですか", "ますか", "について",
                "何か", "いつ", "どの", "どれ", "何")
SOURCES_RE = re.compile(r"出典|何ファイル|どのファイル|どの資料|どの文書|根拠は")
REASON_RE = re.compile(r"^(その)?(理由|わけ|根拠)(も|は|を)?")
COVERAGE_RE = re.compile(r"対象外?(か|です|になる|となる|に入る|なの|に含まれ|内)|"
                         r"保証(され|でき|は効|が効|がき|を受け|修理)|適用され")
EXCLUSION = ("対象外", "適用外", "保証外", "除外", "含まれない", "含まない")
POINTER_RE = re.compile(r"書いてある|記載(して|が)ある|を参照|を見る")
TYPE_HINTS = [(re.compile(r"電話|連絡先|問い合わせ先"), re.compile(r"\d{2,4}-\d{2,4}-\d{3,4}"))]

DATE_RE = re.compile(r"(?:(\d{4})\s*年\s*)?(\d{1,2})\s*月\s*(\d{1,2})\s*日")
DATE_MASK_RE = re.compile(r"\d{4}\s*年(?:\s*\d{1,2}\s*月)?(?:\s*\d{1,2}\s*日)?|\d{1,2}\s*月\s*\d{1,2}\s*日")
REL_RE = re.compile(r"前々日|前日|翌々日|翌日|(\d+)\s*日前|(\d+)\s*日後")
MONTHS_RE = re.compile(r"(\d+)\s*(か月|ヶ月|カ月|ケ月|箇月|年)")
WEEKDAYS = "月火水木金土日"

# 単位 -> (次元, 基準単位への係数)
UNITS = {
    "mm": ("長さ", 0.1), "cm": ("長さ", 1.0), "m": ("長さ", 100.0), "km": ("長さ", 100000.0),
    "g": ("重さ", 1.0), "kg": ("重さ", 1000.0),
    "ml": ("容量", 1.0), "l": ("容量", 1000.0),
    "w": ("電力", 1.0), "kw": ("電力", 1000.0),
    "秒": ("時間", 1.0), "分": ("時間", 60.0), "時間": ("時間", 3600.0),
    "か月": ("月数", 1.0), "年": ("月数", 12.0),
    "日": ("日数", 1.0), "回": ("回", 1.0), "枚": ("枚", 1.0), "円": ("円", 1.0),
    "個": ("個", 1.0), "本": ("本", 1.0), "人": ("人", 1.0), "度": ("度", 1.0),
}
_UNIT_ALT = "|".join(sorted(["ヶ月", "カ月", "ケ月", "箇月", *UNITS], key=len, reverse=True))
QTY_RE = re.compile(rf"(?<![A-Za-z0-9.\-])(約\s*)?(\d+(?:\.\d+)?)\s*({_UNIT_ALT})(?![A-Za-z])", re.I)
ASK_UNIT_RE = re.compile(rf"何\s*({_UNIT_ALT})(?![A-Za-z])", re.I)


def nfkc(s: str) -> str:
    return unicodedata.normalize("NFKC", s)


def _unit_key(u: str) -> str:
    u = u.lower()
    return "か月" if u in ("ヶ月", "カ月", "ケ月", "箇月") else u


def _fmt_num(x: float) -> str:
    return str(int(x)) if abs(x - round(x)) < 1e-9 else f"{x:g}"


@dataclass
class Quantity:
    text: str        # 資料での表記 (例: "28 cm")
    unit: str
    dim: str
    canon: float     # 基準単位での値
    label: str       # 数値の直前の語 (例: "庫内幅")


def quantities(text: str) -> list[Quantity]:
    t = nfkc(text)
    masked = DATE_MASK_RE.sub(lambda m: " " * len(m.group(0)), t)
    out = []
    for m in QTY_RE.finditer(masked):
        unit = _unit_key(m.group(3))
        dim, factor = UNITS[unit]
        label = re.split(r"[、。・:：(（×x/]", t[max(0, m.start() - 10): m.start()])[-1].strip()
        out.append(Quantity(text=t[m.start(): m.end()].strip(), unit=unit, dim=dim,
                            canon=float(m.group(2)) * factor, label=label))
    return out


@dataclass
class DateRef:
    month: int
    day: int
    year: int | None = None

    def fmt(self, with_year: bool = True) -> str:
        y = f"{self.year}年" if (self.year and with_year) else ""
        return f"{y}{self.month}月{self.day}日"

    def as_date(self, default_year: int | None = None) -> dt.date | None:
        y = self.year or default_year
        try:
            return dt.date(y, self.month, self.day) if y else None
        except ValueError:
            return None


def find_dates(text: str) -> list[tuple[int, DateRef]]:
    return [(m.start(), DateRef(int(m.group(2)), int(m.group(3)), int(m.group(1)) if m.group(1) else None))
            for m in DATE_RE.finditer(nfkc(text))]


def find_event_range(text: str) -> tuple[dt.date, dt.date, str] | None:
    """質問中の出来事の日付 (年つき)。「2025年1月」のような年月だけの指定は月初〜月末の範囲。"""
    for _, d in find_dates(text):
        day = d.as_date()
        if d.year and day:
            return day, day, d.fmt()
    m = re.search(r"(\d{4})\s*年\s*(\d{1,2})\s*月", nfkc(text))
    if m and 1 <= int(m.group(2)) <= 12:
        y, mo = int(m.group(1)), int(m.group(2))
        return dt.date(y, mo, 1), dt.date(y, mo, calendar.monthrange(y, mo)[1]), f"{y}年{mo}月"
    return None


def add_months(d: dt.date, n: int) -> dt.date:
    y, m = divmod(d.year * 12 + d.month - 1 + n, 12)
    return dt.date(y, m + 1, min(d.day, calendar.monthrange(y, m + 1)[1]))


def split_facets(query: str) -> list[str]:
    """質問を小問に分ける。「Aと、B」は並列、疑問語を含む読点区切りも分ける。"""
    facets: list[str] = []
    for sent in re.split(r"[。？?！!\n]+", query):
        for coord in re.split(r"(?<=と)[、，]", sent.strip()):
            pieces = [x.strip() for x in re.split(r"[、，]", coord) if x.strip()]
            groups: list[str] = []
            buf: list[str] = []
            for pc in pieces:
                buf.append(pc)
                if QWORD.search(pc):
                    groups.append("、".join(buf))
                    buf = []
            if buf:
                if groups:
                    groups[-1] += "、" + "、".join(buf)
                else:
                    groups.append("、".join(buf))
            facets.extend(groups)
    return facets


def _content_tokens(text: str) -> list[str]:
    t = norm(text)
    for sp in STOP_PHRASES:
        t = t.replace(sp, " ")
    return tokenize(t)


@dataclass
class Evidence:
    file: str
    quote: str


@dataclass
class Part:
    kind: str
    text: str
    passages: list[Passage]
    label: str = ""
    date: dt.date | None = None          # when: 解決した日付
    year_from: str | None = None         # 年を補完した資料


@dataclass
class Result:
    query: str
    found: bool
    answer: str
    evidence: list[Evidence] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    parts: list[Part] = field(default_factory=list)

    @property
    def files(self) -> list[str]:
        return list(dict.fromkeys(e.file for e in self.evidence))

    def to_dict(self) -> dict:
        return {"query": self.query, "found": self.found, "answer": self.answer,
                "evidence": [{"file": e.file, "quote": e.quote} for e in self.evidence],
                "notes": self.notes,
                "parts": [{"kind": p.kind, "label": p.label, "text": p.text,
                           "files": list(dict.fromkeys(x.file for x in p.passages))} for p in self.parts]}

    def render(self) -> str:
        lines = [f"質問: {self.query}", ""]
        ans = self.answer.split("\n")
        lines.append(f"答え: {ans[0]}")
        lines.extend(f"      {a}" for a in ans[1:])
        if self.evidence:
            lines += ["", "根拠:"]
            lines += [f"  [{i}] {e.file}: 「{e.quote}」" for i, e in enumerate(self.evidence, 1)]
        if self.notes:
            lines += ["", "補足:"]
            lines += [f"  - {n}" for n in self.notes]
        return "\n".join(lines)


class Answerer:
    MIN_COVERAGE = 0.2     # これ未満の一致しかなければ「見つからない」とする

    def __init__(self, idx: Index, query: str) -> None:
        self.idx = idx
        self.query = query.strip()
        self.ent_hits = idx.resolve_entities(self.query, SYNONYMS)
        self.ents: list[Entity] = [h.entity for h in self.ent_hits]
        self.qdates = [d for _, d in find_dates(self.query)]
        self.want_sources = False
        self.notes: list[str] = []

    # ------------------------------------------------------------ retrieval
    def _weights(self, facet: str) -> dict[str, float]:
        w = {t: 0.4 for t in _content_tokens(self.query)}
        w.update({t: 1.0 for t in _content_tokens(facet)})
        return w

    def _search(self, facet: str, files: list[str] | None = None) -> list[tuple[float, Passage]]:
        boost: dict[int, float] = {}
        hints = [pat for trig, pat in TYPE_HINTS if trig.search(self.query)]
        for p in self.idx.passages:
            b = 1.0
            if self.ents and self.idx.in_scope(p, self.ents):
                b *= 1.5
            if any(h.search(p.text) for h in hints):
                b *= 2.0
            if b != 1.0:
                boost[p.pid] = b
        hits = self.idx.search(self._weights(facet), boost)
        if files is not None:
            hits = [h for h in hits if h[1].file in files]
        return hits

    def _src(self, p: Passage) -> str:
        return f"{p.title}（{p.file}）"

    def _doc_year(self, file: str) -> int | None:
        for p in self.idx.passages:
            if p.file == file:
                m = re.search(r"(\d{4})\s*年", nfkc(p.text))
                if m:
                    return int(m.group(1))
        return None

    # ------------------------------------------------------------- handlers
    def _coverage(self, facet: str) -> Part | None:
        idx, qn = self.idx, norm(self.query)
        scope = [p for p in idx.passages if not self.ents or idx.in_scope(p, self.ents)]
        reasons: list[str] = []
        used: list[Passage] = []
        items_hit: list[str] = []

        def is_list(p: Passage) -> bool:
            return bool(p.key) and any(m in p.key for m in EXCLUSION)

        # (1) 「保証対象外: A、B、C」のような除外リストに質問の品目があるか
        for p in scope:
            if not is_list(p):
                continue
            items = [it.strip(" 。.") for it in re.split(r"[、,・/]", p.value or "")]
            hit = [it for it in items if len(it) >= 2 and norm(it) in qn]
            if hit:
                reasons.append(f"{self._src(p)}の「{p.key}」に「{'」「'.join(hit)}」が含まれる")
                used.append(p)
                items_hit += hit
        # (2) 本文中の「対象外」という記述 (質問と関連が強い段落のみ)
        for p in scope:
            if is_list(p) or p.is_title:
                continue
            sent = next((s for s in p.sentences if any(m in s for m in EXCLUSION)
                         and not re.search(r"(対象外|適用外|保証外)(では|で)ない", s)), None)
            if not sent:
                continue
            if any(norm(it) in p.ntext for it in items_hit) or self._item_overlap(facet, p) >= 0.5:
                also = "にも" if reasons else "に"
                reasons.append(f"{self._src(p)}{also}「{sent.rstrip('。')}」と書かれている")
                used.append(p)
        excluded = bool(reasons)

        # (3) 保証期間: 購入日 + N か月 と、質問中の日付を比べる
        expired = within = False
        expiry_txt = ""
        event = find_event_range(self.query)
        files = list(dict.fromkeys([f for e in self.ents for f in e.home_files] + [p.file for p in used]))
        for f in files:
            docp = [p for p in idx.passages if p.file == f and p.key]
            period = next((p for p in docp if "保証期間" in p.key), None)
            start_p = next((p for p in docp if re.search(r"購入日|購入年月日|お買い上げ", p.key)
                            and any(d.year for _, d in find_dates(p.value or ""))), None)
            if not (period and start_p and event):
                continue
            val = nfkc(period.value or "")
            base = MONTHS_RE.search(re.sub(r"[（(].*?[）)]", "", val))
            if not base:
                continue
            months, part_name = int(base.group(1)) * (12 if base.group(2) == "年" else 1), ""
            for inner in re.findall(r"[（(](.*?)[）)]", val):
                for name, n, u in re.findall(r"([^、,（(）)\s]+?)は\s*(\d+)\s*(か月|ヶ月|カ月|ケ月|箇月|年)", inner):
                    if norm(name) in qn:
                        months, part_name = int(n) * (12 if u == "年" else 1), name
            start = next(d for _, d in find_dates(start_p.value or "") if d.year)
            expiry = add_months(start.as_date(), months)
            ev_first, ev_last, ev_txt = event
            target = f"（{part_name}）" if part_name else ""
            expiry_txt = f"{expiry.year}年{expiry.month}月{expiry.day}日"
            desc = (f"保証期間{target}は購入日 {start.fmt()} から{months}か月（{expiry_txt}まで）"
                    f"〔{self._src(period)}〕")
            if ev_first > expiry:
                expired = True
                reasons.append(f"{desc}で、{ev_txt}はすでに期間を過ぎている")
            elif ev_last <= expiry:
                within = True
                self.notes.append(f"{desc}で、{ev_txt}は期間内。")
            else:
                self.notes.append(f"{desc}。{ev_txt}のうち何日かによって期間内かどうかが変わります。")
            used += [period, start_p]
            break

        if excluded or expired:
            marks = "①②③④⑤⑥⑦⑧⑨"
            body = " ".join(f"{marks[i] if i < len(marks) else '・'}{r}。" for i, r in enumerate(reasons))
            return Part("coverage", f"対象外。理由: {body}", used, label="保証の可否")
        if within:
            return Part("coverage", f"保証期間内（{expiry_txt}まで）で、対象外とする記載は見つかりません。"
                                    "対象になる可能性があります（最終判断は販売店へ）。", used, label="保証の可否")
        # 判定の決め手がない: 断定せず、手がかりだけ示す
        lists = [p for p in scope if is_list(p)]
        if lists:
            desc = "、".join(f"{self._src(p)}の「{p.key}」は「{(p.value or '').rstrip('。')}」" for p in lists)
            return Part("coverage", f"資料だけでは判定できません。{desc}で、質問の品目がこれに当たるかは"
                                    "資料からは分かりません。", lists + used, label="保証の可否")
        if used:
            return Part("coverage", "資料だけでは判定できません。", used, label="保証の可否")
        return Part("coverage", "資料だけでは判定できません（保証の対象・対象外についての記載が見つかりません）。",
                    [], label="保証の可否")

    def _item_overlap(self, facet: str, p: Passage) -> float:
        """質問の「品目・出来事」部分 (製品名・日付・保証の語を除いた残り) が段落に現れる割合。"""
        t = DATE_MASK_RE.sub(" ", nfkc(facet))
        for h in self.ent_hits:
            t = t.replace(h.surface, " ").replace(h.entity.model, " ")
        t = re.sub(r"保証|修理|対象外?|適用|ですか|ますか|される|できる", " ", t)
        toks = {x for x in tokenize(t) if len(x) == 2 and not re.fullmatch(f"[{HIRA}]+", x)}
        return len([x for x in toks if x in p.tf]) / len(toks) if toks else 0.0

    def _when(self, facet: str) -> Part | None:
        hits = self._search(facet)
        if not hits:
            return None
        top = hits[0][0]
        known = {(d.month, d.day) for d in self.qdates}
        ftoks = set(_content_tokens(facet))
        for score, p in hits[:6]:
            if score < 0.35 * top:
                break
            anchor: DateRef | None = None
            best: tuple[float, str, DateRef | None, str] | None = None   # (重なり, 表現, 日付, 文)
            for sent in split_sentences(nfkc(p.text)):
                overlap = len(ftoks & set(tokenize(sent)))
                for _, d in find_dates(sent):
                    anchor = d
                    if (d.month, d.day) not in known and (best is None or overlap > best[0]):
                        best = (overlap, d.fmt(), d, sent)
                for m in REL_RE.finditer(sent):
                    base = anchor or (self.qdates[0] if self.qdates else None)
                    if m.group(0) in ("前々日", "前日", "翌日", "翌々日"):
                        delta = {"前々日": -2, "前日": -1, "翌日": 1, "翌々日": 2}[m.group(0)]
                    else:
                        delta = -int(m.group(1)) if m.group(1) else int(m.group(2))
                    if best is None or overlap >= best[0]:
                        best = (overlap, m.group(0), None, sent)
                        rel = (base, delta)
            if not best:
                continue
            _, expr, absdate, _sent = best
            if absdate is not None:
                year = absdate.year or self._doc_year(p.file)
                return Part("when", absdate.fmt(), [p], label="いつ", date=absdate.as_date(year),
                            year_from=None if absdate.year else p.file)
            base, delta = rel
            if base is None:
                return Part("when", expr, [p], label="いつ")
            doc_year = self._doc_year(p.file)
            year = base.year or next((d.year for d in self.qdates if d.year), None) or doc_year
            base_date = base.as_date(year or 2001)      # 年が不明でも月日は計算できる
            if base_date is None:
                return Part("when", expr, [p], label="いつ")
            res = base_date + dt.timedelta(days=delta)
            shown = f"{res.year}年{res.month}月{res.day}日" if base.year else f"{res.month}月{res.day}日"
            return Part("when", f"{expr}（{shown}）", [p], label="いつ",
                        date=res if year else None,
                        year_from=p.file if (year and not base.year and year == doc_year) else None)
        return None

    def _which(self, facet: str, head: str) -> Part | None:
        hits = self._search(facet)
        pat = re.compile(f"([{CJK}]*){re.escape(head)}")
        cand: dict[str, float] = {}
        for score, p in hits[:8]:
            for m in pat.finditer(p.text):
                pre = re.split(r"[はがをにでとのもへや]", m.group(1))[-1]
                if pre:
                    cand[pre + head] = cand.get(pre + head, 0.0) + score
        if not cand:
            return None
        keys = set(self.idx.fact_keys)
        term = max(cand, key=lambda t: cand[t] * (1.5 if t in keys else 1.0))
        usage = [p for _, p in hits[:8] if term in p.text and p.key != term][:2]
        defs = self.idx.facts(term)
        bits = [f"「{p.text}」〔{p.file}〕" for p in usage]
        bits += [f"内容: {p.value}〔{p.file}〕" for p in defs]
        return Part("which", f"{term} — " + " ／ ".join(bits) if bits else term, usage + defs, label=head)

    def _quantity(self, facet: str, unit: str) -> Part | None:
        dim = UNITS[unit][0]
        fchars = set(re.findall(f"[{KATA}{KANJI}]", facet))
        top = None
        cands: list[tuple[float, Passage, Quantity]] = []
        for score, p in self._search(facet):
            if self.ents and not self.idx.in_scope(p, self.ents):
                continue
            top = top or score
            if score < 0.35 * top:
                break
            qs = [q for q in quantities(p.text) if q.dim == dim]
            if not qs:
                continue
            qs.sort(key=lambda q: -len(fchars & set(q.label)))
            if len(qs) > 1 and len(fchars & set(qs[0].label)) == len(fchars & set(qs[1].label)):
                continue        # どの数値のことか決められない
            cands.append((score, p, qs[0]))
        if not cands:
            return None
        groups: dict[float, list[tuple[float, Passage, Quantity]]] = {}
        for c in cands:
            groups.setdefault(round(c[2].canon, 6), []).append(c)
        best = max(groups.values(), key=lambda g: sum(c[0] for c in g))
        q = best[0][2]
        text = q.text
        if q.unit != unit:
            text += f"（= {_fmt_num(q.canon / UNITS[unit][1])} {unit}）"
        files = list(dict.fromkeys(c[1].file for c in best))
        if len(files) > 1:
            text += f"（{len(files)} 資料で一致）"
        if len(groups) > 1:
            others = "、".join(f"{g[0][2].text}〔{g[0][1].file}〕" for g in groups.values() if g is not best)
            self.notes.append(f"資料によって値が異なります。別の記載: {others}")
        return Part("quantity", text + "。", [c[1] for c in best], label=q.label)

    def _field(self, facet: str) -> Part | None:
        nf = norm(facet)
        keys: list[str] = []
        for k in self.idx.fact_keys:                      # 長いキーを優先 (部分一致の重複は除く)
            if len(k) >= 2 and norm(k) in nf and not any(k in k2 for k2 in keys):
                keys.append(k)
        if not keys:
            return None
        keys.sort(key=lambda k: nf.index(norm(k)))
        ent_hits = self.idx.resolve_entities(facet, SYNONYMS) or self.ent_hits
        bits: list[str] = []
        used: list[Passage] = []

        def add(p: Passage) -> None:
            if p not in used:
                used.append(p)

        for key in keys:
            identity = any(k in key for k in IDENTITY_KEYS)
            if not ent_hits:
                for p in self.idx.facts(key):
                    bits.append(f"{key}は {(p.value or '').rstrip('。')}〔{p.file}〕")
                    add(p)
                continue
            for h in ent_hits:
                e = h.entity
                who = h.surface if len(keys) == 1 else f"{h.surface}の{key}"
                facts = self.idx.facts(key, e.home_files)
                value = (facts[0].value or "").rstrip("。") if facts else None
                if identity:
                    # 型番: 宣言している資料の行と、言及している別資料 (裏づけ) を根拠にする
                    facts = facts or [p for p in self.idx.passages if p.file in e.home_files and p.key
                                      and any(k in p.key for k in IDENTITY_KEYS)
                                      and e.model in nfkc(p.value or "")]
                    value = e.model
                    mentions = [self.idx.passages[i] for i in e.mentions]
                    support = next((p for p in mentions if p.file not in e.home_files), None)
                    for p in facts[:1] + ([support] if support else []) or mentions[:1]:
                        add(p)
                elif facts:
                    add(facts[0])
                bits.append(f"{who}は {value}" if value else f"{h.surface}の「{key}」は資料に記載なし")
        if not bits:
            return None
        return Part("field", "、".join(bits) + "。", used, label="・".join(keys))

    def _default(self, facet: str) -> Part | None:
        hits = self._search(facet)
        if not hits:
            return None
        _, p = hits[0]
        fw = {t: 1.0 for t in _content_tokens(facet)}
        if self.idx.coverage(fw, p) < self.MIN_COVERAGE:
            return None
        if POINTER_RE.search(p.text):
            # 「〜は△△に書いてある」: 参照先の資料を特定して、そこから答えを引く
            ptoks = {t for t in tokenize(p.text) if len(t) > 1 and not re.fullmatch(f"[{HIRA}]+", t)}
            best_file, best_n = None, 1
            for f, title in self.idx.titles.items():
                n = len(ptoks & set(tokenize(title)))
                if f != p.file and n > best_n:
                    best_file, best_n = f, n
            if best_file:
                sub = [h for h in self._search(facet, [best_file]) if not h[1].is_title]
                if sub:
                    t = sub[0][1]
                    self.notes.append(f"{p.file} の案内「{p.text}」に従い、{t.file} を参照しました。")
                    return Part("default", t.text, [t, p])
        return Part("default", p.text, [p])

    # ---------------------------------------------------------------- main
    def _answer_facet(self, facet: str) -> Part | None:
        nf = nfkc(facet)
        part = None
        if COVERAGE_RE.search(nf):
            part = self._coverage(facet)
        if part is None and re.search(r"いつ|何日|何月何日", nf):
            part = self._when(facet)
        if part is None:
            m = re.search(f"どの\\s*([{KATA}{KANJI}]{{2,}})", nf)
            if m:
                part = self._which(facet, m.group(1))
        if part is None:
            m = ASK_UNIT_RE.search(nf)
            unit = _unit_key(m.group(1)) if m else ("円" if "いくら" in nf else None)
            if unit:
                part = self._quantity(facet, unit)
        if part is None:
            part = self._field(facet)
        return part or self._default(facet)

    def run(self) -> Result:
        parts: list[Part] = []
        missing: list[str] = []
        for facet in split_facets(self.query):
            if SOURCES_RE.search(facet):
                self.want_sources = True
                continue
            if REASON_RE.search(facet):
                continue                      # 理由は根拠として常に添える
            part = self._answer_facet(facet)
            if part:
                parts.append(part)
            else:
                missing.append(facet)
        if not parts:
            return Result(self.query, False, "該当する記述が見つかりませんでした。", notes=self.notes)

        evidence: list[Evidence] = []
        for part in parts:
            for p in part.passages:
                ev = Evidence(p.file, p.text)
                if ev not in evidence:
                    evidence.append(ev)
        self._cross_check_numbers(parts)
        self._calendar_check(parts)
        for facet in missing:
            self.notes.append(f"「{facet}」に該当する記述は見つかりませんでした。")

        if len(parts) == 1:
            lines = [parts[0].text]
        else:
            lines = [f"・{p.label}: {p.text}" if p.kind in ("when", "which", "coverage") else f"・{p.text}"
                     for p in parts]
        files = list(dict.fromkeys(e.file for e in evidence))
        if self.want_sources:
            lines.append(f"出典は {len(files)} ファイル: {'、'.join(files)}")
        return Result(self.query, True, "\n".join(lines), evidence, self.notes, parts)

    # ----------------------------------------------------------- post checks
    def _cross_check_numbers(self, parts: list[Part]) -> None:
        """小問どうしの根拠に同じ単位の数値があれば、一致しているか突き合わせる。"""
        seen: list[str] = []
        for i, a in enumerate(parts):
            for b in parts[i + 1:]:
                if not a.passages or not b.passages or a.passages[0] is b.passages[0]:
                    continue
                qa = {(q.dim, round(q.canon, 6)): q for q in quantities(a.passages[0].text)}
                for q in quantities(b.passages[0].text):
                    k = (q.dim, round(q.canon, 6))
                    if k in qa and q.text not in seen:
                        seen.append(q.text)
                        self.notes.append(f"数値の突き合わせ: 「{qa[k].text}」が両方の記述で一致"
                                          f"（{a.passages[0].file} と {b.passages[0].file}）。")

    def _calendar_check(self, parts: list[Part]) -> None:
        """答えの日付の曜日と、根拠の「平日」「週末」などの条件が食い違わないか確かめる。"""
        for part in parts:
            if not part.date:
                continue
            wd = part.date.weekday()
            day = f"{part.date.year}年{part.date.month}月{part.date.day}日"
            src = f"（年は {part.year_from} の記載から補完）" if part.year_from else ""
            for other in parts:
                for p in other.passages:
                    for s in p.sentences:
                        if ("平日" in s and wd >= 5) or (re.search(r"週末|土日|休日", s) and wd < 5):
                            self.notes.append(
                                f"{day}は{WEEKDAYS[wd]}曜日です{src}。{p.file} の「{s}」という条件とは"
                                "曜日が合わないため、その日にそのまま当てはまるかは資料からは確定できません。")
                            return


def answer(idx: Index, query: str) -> Result:
    return Answerer(idx, query).run()
