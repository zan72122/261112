"""家庭ドキュメント横断検索 (offline PDF cross-search)."""
from .index import Index, build_index  # noqa: F401
from .answer import answer  # noqa: F401
