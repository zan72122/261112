"""PDF からテキスト段落を取り出す。

2 通りの抽出器を持つ:
  * pdftotext (poppler) ... PATH にあれば既定で使う。一般的な PDF に強い。
  * builtin            ... 標準ライブラリだけで動く最小パーサ。非暗号化で、
                           Flate/ASCII85 圧縮、WinAnsi または UCS2 系 CMap
                           (例: UniJIS-UCS2-H) のフォントを使う単純な PDF 向け。
どちらも「段落 (文字列) のリスト」を返す。先頭の段落をタイトルとして扱う。
"""
from __future__ import annotations

import base64
import re
import shutil
import subprocess
import zlib
from pathlib import Path

_CJK = r"぀-ヿ㐀-鿿＀-￯　-〿"


def _join_lines(lines: list[str]) -> str:
    """折り返された行を 1 段落に戻す (日本語同士は空白なしで連結)。"""
    out = ""
    for ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        if out and not (re.search(f"[{_CJK}]$", out) and re.match(f"[{_CJK}]", ln)):
            out += " "
        out += ln
    return re.sub(r"[ \t　]+", " ", out).strip()


# --------------------------------------------------------------------------
# pdftotext
# --------------------------------------------------------------------------
def _extract_pdftotext(path: Path) -> list[str]:
    res = subprocess.run(
        ["pdftotext", "-enc", "UTF-8", "-layout", str(path), "-"],
        capture_output=True, check=True, timeout=60,
    )
    text = res.stdout.decode("utf-8", errors="replace").replace("\f", "\n\n")
    blocks = re.split(r"\n[ \t]*\n", text)
    return [p for p in (_join_lines(b.split("\n")) for b in blocks) if p]


# --------------------------------------------------------------------------
# builtin (standard library only)
# --------------------------------------------------------------------------
class UnsupportedPDF(Exception):
    pass


def _decode_stream(dict_src: bytes, raw: bytes) -> bytes:
    m = re.search(rb"/Filter\s*(\[[^\]]*\]|/\w+)", dict_src)
    filters = re.findall(rb"/(\w+)", m.group(1)) if m else []
    data = raw
    for f in filters:
        if f == b"ASCII85Decode":
            data = data.strip()
            if not data.startswith(b"<~"):
                data = b"<~" + data
            data = base64.a85decode(data, adobe=True)
        elif f == b"ASCIIHexDecode":
            data = bytes.fromhex(data.strip().rstrip(b">").decode("ascii"))
        elif f == b"FlateDecode":
            data = zlib.decompress(data)
        else:
            raise UnsupportedPDF(f"unsupported filter {f!r}")
    return data


def _parse_objects(data: bytes) -> dict[int, bytes]:
    return {int(m.group(1)): m.group(2)
            for m in re.finditer(rb"(?<!\d)(\d+)\s+\d+\s+obj\b(.*?)endobj", data, re.S)}


def _stream_of(body: bytes) -> bytes:
    m = re.search(rb"stream\r?\n(.*?)\r?\n?endstream", body, re.S)
    if not m:
        return b""
    return _decode_stream(body[: m.start()], m.group(1))


def _page_ids(objs: dict[int, bytes]) -> list[int]:
    """Catalog -> Pages -> Kids を辿ってページ順を得る。"""
    root = next((b for b in objs.values() if re.search(rb"/Type\s*/Catalog", b)), None)
    order: list[int] = []
    if root:
        m = re.search(rb"/Pages\s+(\d+)\s+\d+\s+R", root)

        def walk(n: int, depth: int = 0) -> None:
            body = objs.get(n, b"")
            if depth > 50:
                return
            if re.search(rb"/Type\s*/Pages", body):
                k = re.search(rb"/Kids\s*\[(.*?)\]", body, re.S)
                for kid in re.findall(rb"(\d+)\s+\d+\s+R", k.group(1) if k else b""):
                    walk(int(kid), depth + 1)
            elif re.search(rb"/Type\s*/Page\b", body):
                order.append(n)

        if m:
            walk(int(m.group(1)))
    if not order:
        order = sorted(n for n, b in objs.items() if re.search(rb"/Type\s*/Page(?!s)\b", b))
    return order


def _font_codecs(objs: dict[int, bytes], page: bytes) -> dict[bytes, str]:
    """フォント名 -> Python codec。"""
    src = page
    m = re.search(rb"/Font\s+(\d+)\s+\d+\s+R", page)
    if m:
        src = objs.get(int(m.group(1)), b"")
    else:
        r = re.search(rb"/Resources\s+(\d+)\s+\d+\s+R", page)
        if r:
            src = objs.get(int(r.group(1)), b"")
            m = re.search(rb"/Font\s+(\d+)\s+\d+\s+R", src)
            if m:
                src = objs.get(int(m.group(1)), b"")
    codecs: dict[bytes, str] = {}
    for name, ref in re.findall(rb"/(\w+)\s+(\d+)\s+\d+\s+R", src):
        body = objs.get(int(ref), b"")
        if not re.search(rb"/Type\s*/Font", body):
            continue
        encs = re.findall(rb"/Encoding\s*/([\w-]+)", body)
        enc = encs[-1].decode("ascii") if encs else "WinAnsiEncoding"
        if "UCS2" in enc or "UTF16" in enc:
            codecs[name] = "utf-16-be"
        elif enc.startswith("Identity") or re.search(rb"/Subtype\s*/Type0", body):
            raise UnsupportedPDF(f"font encoding {enc} needs a CMap (use pdftotext)")
        elif enc == "MacRomanEncoding":
            codecs[name] = "mac_roman"
        else:
            codecs[name] = "cp1252"
    return codecs


_ESC = {b"n": b"\n", b"r": b"\r", b"t": b"\t", b"b": b"\b", b"f": b"\f",
        b"(": b"(", b")": b")", b"\\": b"\\"}
_WS = b" \t\r\n\f\x00"
_DELIM = b"()<>[]{}/%"


def _tokenize(s: bytes):
    i, n = 0, len(s)
    while i < n:
        c = s[i:i + 1]
        if c in _WS:
            i += 1
        elif c == b"%":
            while i < n and s[i:i + 1] not in b"\r\n":
                i += 1
        elif c == b"(":
            depth, i, buf = 1, i + 1, bytearray()
            while i < n and depth:
                ch = s[i:i + 1]
                if ch == b"\\":
                    nx = s[i + 1:i + 2]
                    if nx in _ESC:
                        buf += _ESC[nx]
                        i += 2
                    elif nx.isdigit():
                        m = re.match(rb"[0-7]{1,3}", s[i + 1:i + 4])
                        buf.append(int(m.group(0), 8) & 0xFF)
                        i += 1 + len(m.group(0))
                    elif nx in b"\r\n":
                        i += 3 if s[i + 1:i + 3] == b"\r\n" else 2
                    else:
                        buf += nx
                        i += 2
                    continue
                if ch == b"(":
                    depth += 1
                elif ch == b")":
                    depth -= 1
                    if not depth:
                        i += 1
                        break
                buf += ch
                i += 1
            yield ("str", bytes(buf))
        elif c == b"<" and s[i + 1:i + 2] != b"<":
            j = s.index(b">", i)
            h = re.sub(rb"\s", b"", s[i + 1:j])
            if len(h) % 2:
                h += b"0"
            yield ("str", bytes.fromhex(h.decode("ascii")))
            i = j + 1
        elif c in b"[]":
            yield (c.decode(), None)
            i += 1
        elif c in b"<>{}":
            i += 2 if s[i + 1:i + 2] == c else 1
        elif c == b"/":
            j = i + 1
            while j < n and s[j:j + 1] not in _WS and s[j:j + 1] not in _DELIM:
                j += 1
            yield ("name", s[i + 1:j])
            i = j
        else:
            j = i
            while j < n and s[j:j + 1] not in _WS and s[j:j + 1] not in _DELIM:
                j += 1
            if j == i:  # stray delimiter such as ")"
                i += 1
                continue
            w = s[i:j]
            try:
                yield ("num", float(w))
            except ValueError:
                yield ("op", w)
            i = j


def _content_lines(content: bytes, codecs: dict[bytes, str]) -> list[tuple[float, float, str]]:
    """content stream -> [(y, leading, text)] (出現順)。"""
    lines: list[tuple[float, float, str]] = []
    stack: list = []
    codec, size, leading = "cp1252", 12.0, 0.0
    line_y = y = 0.0
    cur: list[str] = []
    cur_y: float | None = None

    def flush():
        nonlocal cur, cur_y
        if cur and cur_y is not None:
            lines.append((cur_y, leading or size * 1.2, "".join(cur)))
        cur, cur_y = [], None

    def show(b: bytes):
        nonlocal cur_y
        if cur_y is not None and abs(cur_y - y) > 0.5:
            flush()
        if cur_y is None:
            cur_y = y
        cur.append(b.decode(codec, errors="replace"))

    in_array: list | None = None
    for kind, val in _tokenize(content):
        if kind == "[":
            in_array = []
        elif kind == "]":
            stack.append(in_array or [])
            in_array = None
        elif in_array is not None:
            in_array.append(val)
        elif kind != "op":
            stack.append(val)
        else:
            op = val
            try:
                if op == b"Tf":
                    size = float(stack[-1])
                    codec = codecs.get(stack[-2], "cp1252")
                elif op == b"TL":
                    leading = float(stack[-1])
                elif op == b"Tm":
                    line_y = y = float(stack[-1])
                elif op in (b"Td", b"TD"):
                    line_y = y = line_y + float(stack[-1])
                    if op == b"TD":
                        leading = -float(stack[-1])
                elif op == b"T*":
                    line_y = y = line_y - (leading or size * 1.2)
                elif op == b"Tj":
                    show(stack[-1])
                elif op in (b"'", b'"'):
                    line_y = y = line_y - (leading or size * 1.2)
                    show(stack[-1])
                elif op == b"TJ":
                    for item in stack[-1]:
                        if isinstance(item, bytes):
                            show(item)
                elif op in (b"BT", b"ET"):
                    if op == b"BT":
                        line_y = y = 0.0
                    flush()
            except (IndexError, TypeError, ValueError):
                pass
            stack = []
    flush()
    return lines


def _extract_builtin(path: Path) -> list[str]:
    data = path.read_bytes()
    if b"/Encrypt" in data:
        raise UnsupportedPDF("encrypted PDF")
    objs = _parse_objects(data)
    passages: list[str] = []
    for pid in _page_ids(objs):
        page = objs[pid]
        codecs = _font_codecs(objs, page)
        m = re.search(rb"/Contents\s*(\[[^\]]*\]|\d+\s+\d+\s+R)", page)
        refs = re.findall(rb"(\d+)\s+\d+\s+R", m.group(1)) if m else []
        content = b"\n".join(_stream_of(objs.get(int(r), b"")) for r in refs)
        block: list[str] = []
        prev_y = None
        for y, lead, text in _content_lines(content, codecs):
            if not text.strip():
                continue
            if prev_y is not None and not (0 < prev_y - y <= lead * 1.3):
                passages.append(_join_lines(block))
                block = []
            block.append(text)
            prev_y = y
        if block:
            passages.append(_join_lines(block))
    return [p for p in passages if p]


# --------------------------------------------------------------------------
def extract_passages(path: str | Path, extractor: str = "auto") -> list[str]:
    """PDF 1 ファイルを段落のリストにする。extractor: auto | pdftotext | builtin"""
    path = Path(path)
    if extractor == "builtin":
        return _extract_builtin(path)
    if extractor == "pdftotext":
        return _extract_pdftotext(path)
    if shutil.which("pdftotext"):
        try:
            out = _extract_pdftotext(path)
            if out:
                return out
        except (subprocess.SubprocessError, OSError):
            pass
    return _extract_builtin(path)
