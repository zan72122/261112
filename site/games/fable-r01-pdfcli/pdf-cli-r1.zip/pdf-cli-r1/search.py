#!/usr/bin/env python3
"""家庭ドキュメント横断検索 — pdfs/ 内の PDF をオフラインで横断検索する。

使い方:
    python3 search.py "冷蔵庫と電子レンジの型番は何か。"
    python3 search.py                # 対話モード
    python3 search.py --json "質問"  # JSON 出力
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from xsearch import answer, build_index
from xsearch.answer import Answerer

HERE = Path(__file__).resolve().parent


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="家庭ドキュメント横断検索 (オフライン)")
    ap.add_argument("question", nargs="*", help="質問文 (省略すると対話モード)")
    ap.add_argument("--pdf-dir", default=str(HERE / "pdfs"), help="PDF フォルダ (既定: ./pdfs)")
    ap.add_argument("--json", action="store_true", help="JSON で出力")
    ap.add_argument("--top", type=int, default=0, metavar="N", help="検索上位 N 件の段落も表示")
    ap.add_argument("--extractor", choices=["auto", "pdftotext", "builtin"], default="auto",
                    help="PDF テキスト抽出器 (既定: pdftotext があれば使用、なければ内蔵パーサ)")
    ap.add_argument("--dump", action="store_true", help="抽出したテキストを表示して終了")
    args = ap.parse_args(argv)

    try:
        idx = build_index(args.pdf_dir, args.extractor)
    except FileNotFoundError as e:
        print(e, file=sys.stderr)
        return 2

    if args.dump:
        for p in idx.passages:
            print(f"{p.file}\t{'# ' if p.is_title else ''}{p.text}")
        return 0

    def run(q: str) -> None:
        res = answer(idx, q)
        if args.json:
            out = res.to_dict()
            if args.top:
                out["hits"] = [{"score": round(s, 3), "file": p.file, "text": p.text}
                               for s, p in Answerer(idx, q)._search(q)[: args.top]]
            print(json.dumps(out, ensure_ascii=False, indent=2))
            return
        print(res.render())
        if args.top:
            print("\n検索上位:")
            for s, p in Answerer(idx, q)._search(q)[: args.top]:
                print(f"  {s:6.2f}  {p.file}: {p.text}")

    if args.question:
        run(" ".join(args.question))
        return 0

    print(f"{len(idx.files)} ファイル / {len(idx.passages)} 段落を索引しました。質問をどうぞ (空行で終了)。")
    while True:
        try:
            q = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not q:
            break
        run(q)
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
